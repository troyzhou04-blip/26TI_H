#ifndef _DELAY_H
#define _DELAY_H

#include <stdint.h>
#include "ti_msp_dl_config.h"

void delay_us(unsigned long __us);
void delay_ms(unsigned long ms);

extern volatile uint32_t g_run_ms;//毫秒级运行时钟, 由SysTick中断累加
void RunTick_Init(void);//重配置SysTick为1ms周期中断, 提供毫秒级运行时钟


#endif