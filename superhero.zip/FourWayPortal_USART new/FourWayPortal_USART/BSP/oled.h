#ifndef _OLED_H
#define _OLED_H

#include <stdint.h>
#include "ti_msp_dl_config.h"

/*
 * SSD1306 128x64 OLED, I2C0控制器模式, SDA=PA0, SCL=PA1, 400kHz, 地址0x3C
 * 仅使用ASCII字符(6x8点阵), 避免未编码字符导致乱码
 * SSD1306 128x64 OLED on I2C0 (controller), SDA=PA0 SCL=PA1, 400kHz, addr 0x3C
 * ASCII-only 6x8 glyphs, no unencoded characters
 */

void OLED_Init(void);//OLED初始化(清屏并显示初始计时) / OLED init, clear screen
void OLED_ShowTime(uint32_t ms);//更新秒表显示, 内部限流约100ms刷新一次 / throttled stopwatch refresh (~100ms)
void OLED_ShowTimeFinal(uint32_t ms);//强制刷新一次, 用于停车后定格最终时间 / force one refresh for the final time

#endif
