#ifndef __FOUR_LINEWALKING_H__
#define __FOUR_LINEWALKING_H__

#include "ti_msp_dl_config.h"
#include "app_motor_usart.h"

/*
    八路巡线传感器物理排列（从车后往前看，左→右）：
    L4  L3  L2  L1  R1  R2  R3  R4

    X1~X8 与传感器对应关系:
    X1=L4  X2=L3  X3=L2  X4=L1  X5=R1  X6=R2  X7=R3  X8=R4

    传感器电平: LOW=压线(黑)  HIGH=离线(白)
*/

#define LineWalk_L4_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X1_PIN) & Sensor_X1_PIN) > 0) ? 1 : 0)
#define LineWalk_L3_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X2_PIN) & Sensor_X2_PIN) > 0) ? 1 : 0)
#define LineWalk_L2_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X3_PIN) & Sensor_X3_PIN) > 0) ? 1 : 0)
#define LineWalk_L1_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X4_PIN) & Sensor_X4_PIN) > 0) ? 1 : 0)
#define LineWalk_R1_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X5_PIN) & Sensor_X5_PIN) > 0) ? 1 : 0)
#define LineWalk_R2_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X6_PIN) & Sensor_X6_PIN) > 0) ? 1 : 0)
#define LineWalk_R3_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X7_PIN) & Sensor_X7_PIN) > 0) ? 1 : 0)
#define LineWalk_R4_IN  (((DL_GPIO_readPins(Sensor_PORT, Sensor_X8_PIN) & Sensor_X8_PIN) > 0) ? 1 : 0)

#define LOW   (0)
#define HIGH  (1)

// ================================================================
// 直线速度 (mm/s) —— 全套代码中唯一从旧版保留的参数
// 修改前 K1 实际直线速度 = 520 (旧 empty.c 的 K1_STRAIGHT_SPEED 经
// Four_LineWalking_SetSpeed 传入生效, 旧头文件默认的 480 从未被使用),
// 因此这里取 520, 保证修改前后小车直线速度完全一致。
// 想改整车直线速度只改这一个数: K1 全速 / K2 加速目标 / K3 基准都引用它。
// ================================================================
#define LINE_STRAIGHT_SPEED  (520)

void Four_LineWalking(void);
void Four_LineWalking_Reset(void);
int  Four_StopLineDetected(void);
void Four_LineWalking_SetSpeed(int base);

#endif
