#include "Four_linewalking.h"
#include "delay.h"

// ================================================================
//  差速巡线控制器 (全新重写)
//  车型: 前一个万向轮 + 后两轮独立驱动, 八路传感器排在车头最前方
//
//  控制思路 (针对"传感器远在前、驱动轮在后"的结构):
//  传感器比驱动轴超前很多, 车身一有角度偏差, 传感器读数就被放大,
//  所以这套结构天生"反应早但容易晃"。因此:
//   - 误差分四档状态分别处理, 不用一套增益打天下
//   - 直线修正刻意调柔 (CORRECT_GAIN), 大转弯才用全力
//   - 转向输出直接是"左右轮速差 mm/s", 由本文件自己做差速分配,
//     不再经过 Motion_Car_Control 的角速度换算
//
//  状态机:
//   CENTER  居中:    |e|<=E_DEAD, 不修正, 全速直行
//   CORRECT 直线修正: 内侧传感器小偏差, 柔和修正, 全速
//   TURN    大转弯:  最外侧L4/R4压线或|e|>=E_SHARP, 全力度修正+降速
//   LOST    丢线:    八路全白, 按丢线前记忆慢速找线
// ================================================================

// ---- 误差计算 ----
// 八路权重 L4~R4: -7 -5 -3 -1 +1 +3 +5 +7, 按压线路数取平均,
// 误差 e 范围 -7(线在最左) ~ +7(线在最右), 正=线在右=应向右转

// ---- 状态判定阈值 (作用于本周期误差 e) ----
#define E_DEAD      (0.8f)   // |e|<=此值: 居中死区, 完全不修正, 防直道来回晃
#define E_SHARP     (3.5f)   // |e|>=此值 或 L4/R4压线: 判定大转弯
#define E_LOST      (1.5f)   // 丢线时 |滤波误差|<此值→直走(过缝隙), 否则保持方向找线

// ---- 误差低通滤波 ----
// e_filt += (e - e_filt) * FILT_A; 越大越灵敏越易抖, 传感器靠前宜偏滤波
#define FILT_A      (0.6f)

// ---- PID 增益 (输出单位: 单侧轮速修正 mm/s) ----
#define LINE_KP     (13.0f)  // 比例: e=1→60, e=3.5→210, e=7→420(被限幅)
#define LINE_KI     (0.0f)   // 积分: 只在直线修正档累加, 修机械不对称的持续跑偏
#define LINE_KD     (200.0f)  // 微分: 滤波误差每周期变化量, 抑制出弯过冲/蛇形
#define I_MAX       (80.0f)  // 积分限幅(抗饱和)
#define D_MAX       (250.0f) // 微分限幅, 防传感器离散跳变冲击
#define STEER_MAX   (400)    // 转向输出总限幅: 单侧轮速最多修正±400mm/s

// ---- 直线修正柔和度 ----
// CORRECT 档转向输出乘此系数; 传感器靠前, 直线修正必须柔, 否则直道蛇形
#define CORRECT_GAIN (0.3f)

// ---- 速度控制 ----
#define CURVE_MIN_RATIO (0.55f)  // 弯道最低速 = 直线速度*此比例 (520→286)
#define CURVE_MIN_FLOOR (180)    // 弯道最低速下限(低速起步时也不会低到推不动)
#define SLOW_K          (0.5f)   // 大转弯降速: v = base - |steer|*SLOW_K
#define LOST_SPEED      (300)    // 丢线找线时的固定低速

// ---- 控制节拍 ----
#define CTRL_DT_MS      (5)      // PID与电机命令固定5ms更新一次

// ---- 传感器去抖 ----
#define FILTER_CONFIRM  (2)      // 连续N次一致才更新, 滤反光毛刺

// ---- 停止线 ----
#define STOP_THRESHOLD  (3)      // N路及以上同时压线→停止线(任务要求任意三路)


// ================================================================
//  状态变量
// ================================================================

// 传感器去抖: 稳定电平 + 变化计数
static int line_state[8] = {HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH, HIGH};
static int line_cnt[8]   = {0, 0, 0, 0, 0, 0, 0, 0};

// 控制状态
static float e_filt       = 0.0f;   // 滤波后误差 (P/I/D 都用它, 输出平滑)
static float e_filt_prev  = 0.0f;   // 上周期滤波误差, 供D项差分
static float integral     = 0.0f;   // 积分累加
static uint32_t last_ctrl_ms = 0;   // 上一次控制周期时刻

// 当前直线速度 (mm/s), K2/K3 加速过程通过 SetSpeed 逐步抬高
static int base_speed = LINE_STRAIGHT_SPEED;

// 电机命令去重缓存
static int last_left_sent  = -1;
static int last_right_sent = -1;


// ================================================================
//  设置直线速度 (K2/K3 加速斜坡每拍调用)
// ================================================================
void Four_LineWalking_SetSpeed(int base)
{
    base_speed = base;
}


// ================================================================
//  差速驱动输出 (本文件自有, 替代 Motion_Car_Control 的角速度换算)
//  left/right: 左右轮目标前进速度 mm/s (>=0)
//  左轮接驱动板M2口, 右轮接M4口, M1/M3不接线
//  由 app_motor.c 可知该驱动板负值=前进, 所以下发时取反
// ================================================================
static void drive_wheels(int left, int right)
{
    if (left  > 1000) left  = 1000;
    if (left  < 0)    left  = 0;      // 不允许倒退, 大弯时内侧轮最多停转
    if (right > 1000) right = 1000;
    if (right < 0)    right = 0;

    if (left != last_left_sent || right != last_right_sent) {
        Contrl_Speed(0, (int16_t)(-left), 0, (int16_t)(-right));
        last_left_sent  = left;
        last_right_sent = right;
    }
}


// ================================================================
//  传感器去抖
// ================================================================
static int sensor_filter(int raw, int idx)
{
    if (raw == line_state[idx]) {
        line_cnt[idx] = 0;
    } else if (++line_cnt[idx] >= FILTER_CONFIRM) {
        line_state[idx] = raw;
        line_cnt[idx]   = 0;
    }
    return line_state[idx];
}


// ================================================================
//  复位 (每轮循迹开始前调用)
// ================================================================
void Four_LineWalking_Reset(void)
{
    int i;
    for (i = 0; i < 8; i++) {
        line_state[i] = HIGH;
        line_cnt[i]   = 0;
    }
    e_filt       = 0.0f;
    e_filt_prev  = 0.0f;
    integral     = 0.0f;
    last_ctrl_ms = 0;
    last_left_sent  = -1;
    last_right_sent = -1;
}


// ================================================================
//  停止线检测: 去抖后的稳定电平, >=STOP_THRESHOLD路同时压线
// ================================================================
int Four_StopLineDetected(void)
{
    int active = 0;
    int i;
    for (i = 0; i < 8; i++) {
        if (line_state[i] == LOW) active++;
    }
    return (active >= STOP_THRESHOLD) ? 1 : 0;
}


// ================================================================
//  主控制函数 (主循环高频调用, 内部按CTRL_DT_MS节拍更新)
// ================================================================
void Four_LineWalking(void)
{
    // ---- 第1步: 读八路传感器(去抖) 并计算本周期误差 ----
    static const int W[8] = {-7, -5, -3, -1, 1, 3, 5, 7};
    int s[8];
    int active_cnt = 0;
    int weight_sum = 0;
    int i;

    s[0] = sensor_filter(LineWalk_L4_IN, 0);
    s[1] = sensor_filter(LineWalk_L3_IN, 1);
    s[2] = sensor_filter(LineWalk_L2_IN, 2);
    s[3] = sensor_filter(LineWalk_L1_IN, 3);
    s[4] = sensor_filter(LineWalk_R1_IN, 4);
    s[5] = sensor_filter(LineWalk_R2_IN, 5);
    s[6] = sensor_filter(LineWalk_R3_IN, 6);
    s[7] = sensor_filter(LineWalk_R4_IN, 7);

    for (i = 0; i < 8; i++) {
        if (s[i] == LOW) {
            weight_sum += W[i];
            active_cnt++;
        }
    }

    float e;        // 本周期误差, 正=线在右
    int   mode;     // 0=CENTER 1=CORRECT 2=TURN 3=LOST

    if (active_cnt > 0) {
        e = (float)weight_sum / (float)active_cnt;   // -7 ~ +7

        if (e > -E_DEAD && e < E_DEAD) {
            mode = 0;                                // CENTER 居中
        } else if (s[0] == LOW || s[7] == LOW ||
                   e >= E_SHARP || e <= -E_SHARP) {
            mode = 2;                                // TURN 大转弯
        } else {
            mode = 1;                                // CORRECT 直线修正
        }
    } else {
        // 八路全白: 误差保持丢线前的记忆(小误差归零直走, 大误差保持找线)
        if (e_filt > -E_LOST && e_filt < E_LOST)
            e = 0.0f;
        else
            e = e_filt;
        mode = 3;                                    // LOST 丢线
    }

    // ---- 第2步: 误差低通滤波, P/I/D统一使用滤波误差, 输出平滑 ----
    e_filt += (e - e_filt) * FILT_A;

    // ---- 第3步: 固定节拍门控 ----
    if ((uint32_t)(g_run_ms - last_ctrl_ms) < CTRL_DT_MS) return;
    last_ctrl_ms = g_run_ms;

    // ---- 第4步: PID 计算 ----
    // P 比例: 误差越大转向越狠
    float p_out = LINE_KP * e_filt;

    // I 积分: 只在直线修正档累加(修持续跑偏), 其余档位快速泄放防饱和;
    //         误差过零直接清零, 防止积分拖着车冲过线
    if (mode == 1) {
        integral += e_filt * LINE_KI;
    } else if (mode == 0) {
        integral *= 0.8f;      // 居中: 快速泄放
    } else {
        integral *= 0.9f;      // 转弯/丢线: 慢速泄放
    }
    if ((e_filt > 0.0f && e_filt_prev < 0.0f) ||
        (e_filt < 0.0f && e_filt_prev > 0.0f)) {
        integral = 0.0f;       // 零交叉复位
    }
    if      (integral >  I_MAX) integral =  I_MAX;
    else if (integral < -I_MAX) integral = -I_MAX;

    // D 微分: 滤波误差的变化率, 提前刹车抑制过冲; 限幅防离散跳变冲击
    float d_out = LINE_KD * (e_filt - e_filt_prev);
    e_filt_prev = e_filt;
    if      (d_out >  D_MAX) d_out =  D_MAX;
    else if (d_out < -D_MAX) d_out = -D_MAX;

    // 合成 + 限幅; steer>0 = 向右转(左轮快), steer<0 = 向左转
    float steer_f = p_out + integral + d_out;
    if      (steer_f >  STEER_MAX) steer_f =  STEER_MAX;
    else if (steer_f < -STEER_MAX) steer_f = -STEER_MAX;

    // ---- 第5步: 按状态决定最终转向量与车速 ----
    int steer;
    int v;

    if (mode == 0) {
        // CENTER: 居中死区, 不修正全速直行, 消灭直道来回晃
        steer = 0;
        v = base_speed;
    } else if (mode == 1) {
        // CORRECT: 直线小偏差, 柔和修正, 不降速
        steer = (int)(steer_f * CORRECT_GAIN);
        v = base_speed;
    } else if (mode == 2) {
        // TURN: 大转弯, 全力度转向 + 按转向量降速, 弯道不甩出去
        steer = (int)steer_f;
        int curve_min = (int)(base_speed * CURVE_MIN_RATIO);
        if (curve_min < CURVE_MIN_FLOOR) curve_min = CURVE_MIN_FLOOR;
        v = base_speed - (int)((steer >= 0 ? steer : -steer) * SLOW_K);
        if (v < curve_min) v = curve_min;
    } else {
        // LOST: 丢线找线, 固定低速 + 保持记忆方向
        steer = (int)steer_f;
        v = LOST_SPEED;
    }

    // ---- 第6步: 差速分配下发电机 ----
    // steer>0(线在右)→左轮快右轮慢→向右转; 反之向左转
    drive_wheels(v + steer, v - steer);
}
