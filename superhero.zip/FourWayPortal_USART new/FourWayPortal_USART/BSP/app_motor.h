#ifndef __APP_MOTOR_H_
#define __APP_MOTOR_H_

#include "ti_msp_dl_config.h"
#include "app_motor_usart.h"
#include "delay.h"

//小车底盘电机间距之和的一半
#define Car_APB          				(72.0f)//  双驱车改为: M2与M4两轮间距的一半, 实测后修改

void Set_Motor(int MOTOR_TYPE);
void Motion_Car_Control(int16_t V_x, int16_t V_y, int16_t V_z);


#endif
