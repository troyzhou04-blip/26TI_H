#include "delay.h"

//搭配滴答定时器实现的精确us延时
//Accurate us delay with tick timer
void delay_us(unsigned long __us) 
{
    uint32_t ticks;
    uint32_t told, tnow, tcnt = 38;

    // 计算需要的时钟数 = 延迟微秒数 * 每微秒的时钟数
	// Calculate the number of clocks required = delay microseconds * number of clocks per microsecond
    ticks = __us * (32000000 / 1000000);

    // 获取当前的SysTick值
	// Get the current SysTick value
    told = SysTick->VAL;

    while (1)
    {
        // 重复刷新获取当前的SysTick值
		// Repeatedly refresh to get the current SysTick value
        tnow = SysTick->VAL;

        if (tnow != told)
        {
            if (tnow < told)
                tcnt += told - tnow;
            else
                tcnt += SysTick->LOAD - tnow + told;

            told = tnow;

            // 如果达到了需要的时钟数，就退出循环
			// If the required number of clocks is reached, exit the loop
            if (tcnt >= ticks)
                break;
        }
    }
}
//搭配滴答定时器实现的精确ms延时
//Accurate ms delay with tick timer
void delay_ms(unsigned long ms) 
{
	delay_us( ms * 1000 );
}

//毫秒级运行时钟: 供长时间计时(如按键启动后18.8s自动停车)使用
//RunTick_Init把SysTick重配置为1ms周期并开中断, 中断里累加g_run_ms.
//delay_us读取的是SysTick->LOAD动态值, 重配置后延时函数不受影响
volatile uint32_t g_run_ms = 0;

void SysTick_Handler(void)
{
	g_run_ms++;
}

//重配置SysTick为1ms周期中断(默认配置1us翻转一次, 无法用于长时间计时)
void RunTick_Init(void)
{
	SysTick->LOAD = (32000000 / 1000) - 1;
	SysTick->VAL = 0;
	SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
	NVIC_SetPriority(SysTick_IRQn, 3);//低优先级, 不干扰其他中断
}
