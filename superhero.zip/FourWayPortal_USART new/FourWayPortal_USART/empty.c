#include "ti_msp_dl_config.h"
#include "delay.h"
#include "usart.h"
#include "app_motor_usart.h"
#include "Four_linewalking.h"
#include "app_motor.h"
#include "oled.h"

#define MOTOR_TYPE 3   //1:520电机 2:310电机 3:带编码器TT电机 4:TT直流减速电机 5:L型520电机
                       //1:520 motor 2:310 motor 3:speed code disc TT motor 4:TT DC reduction motor 5:L type 520 motor

// ================================================================
// 按键定义 (引脚不变)
// K1(START): PA2, 内部上拉, 按下低电平 → 全速循迹, 任意三路同时压线停车
// K2:        PB19, 内部上拉, 按下低电平 → 6秒缓提速到直线速度, 再运行8秒停车
// K3:        PB20, 内部上拉, 按下低电平 → 缓提速到比K1慢一些的速度维持, 行驶满30秒停车
// ================================================================
#define KEY_PRESSED()	( ( DL_GPIO_readPins(KEY_START_PORT, KEY_START_PIN) & KEY_START_PIN ) == 0 )
#define K2_PRESSED()	( ( DL_GPIO_readPins(KEY_K2_PORT, KEY_K2_PIN) & KEY_K2_PIN ) == 0 )
#define K3_PRESSED()	( ( DL_GPIO_readPins(KEY_K3_PORT, KEY_K3_PIN) & KEY_K3_PIN ) == 0 )

//按键松开等待(带消抖): TEST为上面的按键宏
#define KEY_WAIT_RELEASE(TEST)	do { delay_ms(20); while (TEST) ; delay_ms(20); } while (0)

// ================================================================
// 三个按键的满速 (mm/s) —— 直接填数字即可, 当前值与调整后的实际速度一致
// ================================================================
#define K1_TOP_SPEED	(450)	//K1满速: 全速循迹的直线速度
#define K2_TOP_SPEED	(400)	//K2满速: 缓提速到的目标速度
#define K3_TOP_SPEED	(290)	//K3满速: 比K1慢一些的维持速度

// ---- K2 参数 ----
#define K2_RAMP_MS	(6000)	//缓提速时间: 6秒内从起步速度升到K2满速
#define K2_HOLD_MS	(2000)	//升到满速后再运行的时间 (总时长=6+2=8秒)

// ---- K3 参数 ----
#define K3_RAMP_MS	(6000)	//缓提速时间: 与K2相同的缓慢加速过程
#define K3_RUN_MS	(30000)	//总运行时间: 行驶满30秒停车

// ---- 加速斜坡公共参数 ----
#define RAMP_START	(60)	//起步速度(mm/s), 保证平稳起步不窜

// ---- 停止线确认 ----
#define STOP_CONFIRM	(3)	//连续N次检测到三路压线才停车, 防误触发


// ================================================================
// K1: 全速循迹, 任意三路同时压线(停止线)停车
// ================================================================
static void Run_K1(void)
{
	KEY_WAIT_RELEASE(KEY_PRESSED());//消抖并等待松手

	Four_LineWalking_Reset();//清零传感器去抖/误差滤波/积分/电机缓存
	Four_LineWalking_SetSpeed(K1_TOP_SPEED);//K1满速
	printf("k1 pressed, line walking until stop line\r\n");

	uint32_t start_ms = g_run_ms;//按键松手开始计时
	OLED_ShowTimeFinal(0);

	int stop_cnt = 0;
	while (stop_cnt < STOP_CONFIRM)
	{
		if (Four_StopLineDetected())	stop_cnt++;
		else	stop_cnt = 0;
		Four_LineWalking();
		OLED_ShowTime(g_run_ms - start_ms);//秒表刷新(内部限流约100ms)
	}

	Motion_Car_Control(0, 0, 0);//停车
	OLED_ShowTimeFinal(g_run_ms - start_ms);//定格最终时间
	printf("stop line detected, car stopped\r\n");
}

// ================================================================
// K2: 6秒内从起步速度缓慢提速到K2满速, 再以该速度运行K2_HOLD_MS停车
// ================================================================
static void Run_K2(void)
{
	KEY_WAIT_RELEASE(K2_PRESSED());//消抖并等待松手

	Four_LineWalking_Reset();
	Four_LineWalking_SetSpeed(RAMP_START);//从起步速度开始
	printf("k2 pressed, ramp 6s then run 8s\r\n");

	uint32_t start_ms = g_run_ms;
	OLED_ShowTimeFinal(0);

	uint32_t total_ms = K2_RAMP_MS + K2_HOLD_MS;
	while (g_run_ms - start_ms < total_ms)
	{
		uint32_t elapsed = g_run_ms - start_ms;

		if (elapsed < K2_RAMP_MS)
		{
			//加速段: 6秒内从RAMP_START线性升到K2满速
			int ramp = RAMP_START + (K2_TOP_SPEED - RAMP_START) * (int)elapsed / K2_RAMP_MS;
			Four_LineWalking_SetSpeed(ramp);
		}
		else
		{
			//匀速段: 保持K2满速跑满K2_HOLD_MS
			Four_LineWalking_SetSpeed(K2_TOP_SPEED);
		}

		Four_LineWalking();
		OLED_ShowTime(elapsed);
	}

	Motion_Car_Control(0, 0, 0);//时间到, 停车
	OLED_ShowTimeFinal(g_run_ms - start_ms);
	printf("k2 finished, car stopped\r\n");
}

// ================================================================
// K3: 缓慢提速到比K1慢一些的速度并维持, 行驶满30秒停车 (不检测停止线)
// ================================================================
static void Run_K3(void)
{
	KEY_WAIT_RELEASE(K3_PRESSED());//消抖并等待松手

	Four_LineWalking_Reset();
	Four_LineWalking_SetSpeed(RAMP_START);//从起步速度开始
	printf("k3 pressed, ramp to slower speed, run for 30s\r\n");

	uint32_t start_ms = g_run_ms;
	OLED_ShowTimeFinal(0);

	while (g_run_ms - start_ms < K3_RUN_MS)
	{
		uint32_t elapsed = g_run_ms - start_ms;

		if (elapsed < K3_RAMP_MS)
		{
			//加速段: 6秒内从RAMP_START线性升到K3满速
			int ramp = RAMP_START + (K3_TOP_SPEED - RAMP_START) * (int)elapsed / K3_RAMP_MS;
			Four_LineWalking_SetSpeed(ramp);
		}
		else
		{
			//匀速段: 维持K3满速直到30秒计时结束
			Four_LineWalking_SetSpeed(K3_TOP_SPEED);
		}

		Four_LineWalking();
		OLED_ShowTime(elapsed);
	}

	Motion_Car_Control(0, 0, 0);//30秒到, 停车
	OLED_ShowTimeFinal(g_run_ms - start_ms);
	printf("k3 finished, car stopped\r\n");
}

int main(void)
{
	USART_Init();
	printf("please wait...");

	RunTick_Init();//重配置SysTick为1ms中断, 提供毫秒级运行时钟

    Set_Motor(MOTOR_TYPE);

    //配置电机驱动板的速度环PID (P=1.9 I=0.2 D=0.8), 底盘不同需实测调整
    //Configure motor driver board speed-loop PID, adjust for different chassis
	send_motor_PID(1.9,0.2,0.8);

    delay_ms(100);

	Motion_Car_Control(0, 0, 0);//上电先确保电机停止

	OLED_Init();//OLED初始化, I2C0: SDA=PA0 SCL=PA1
	OLED_ShowTimeFinal(0);//显示初始计时 time: 0.00s

	while(1)
	{
		printf("wait key\r\n");

		//等待任意按键: K1全速循迹 / K2定时循迹 / K3慢速循迹
		while (!KEY_PRESSED() && !K2_PRESSED() && !K3_PRESSED())	;

		if (KEY_PRESSED())	{ Run_K1(); continue; }
		if (K2_PRESSED())	{ Run_K2(); continue; }
		Run_K3();
	}

}
