#include "oled.h"
#include "delay.h"

#define OLED_I2C_ADDR    (0x3C)//SSD1306常见7位地址 / typical SSD1306 7-bit address
#define OLED_WIDTH       (128)
#define OLED_TIME_PAGE   (2)//计时显示所在页(y=16) / page where the time string is drawn
#define OLED_TIME_COL    (0)
#define OLED_LINE_CHARS  (16)//时间行固定宽度, 不足补空格覆盖旧字符 / fixed line width, space padded

//阻塞式I2C发送: FIFO写满后等其排空再续填, 一次START到STOP发完
//Blocking I2C TX: refill as the FIFO drains, single START..STOP transaction
static void oled_i2c_send(const uint8_t *buf, uint16_t len)
{
    uint16_t sent;

    DL_I2C_flushControllerTXFIFO(I2C_0_INST);
    sent = DL_I2C_fillControllerTXFIFO(I2C_0_INST, buf, len);//返回实际写入数 / returns bytes actually written

    while (!(DL_I2C_getControllerStatus(I2C_0_INST) & DL_I2C_CONTROLLER_STATUS_IDLE))
        ;

    DL_I2C_startControllerTransfer(I2C_0_INST, OLED_I2C_ADDR,
                                   DL_I2C_CONTROLLER_DIRECTION_TX, len);
    while (sent < len)
    {
        while (!DL_I2C_isControllerTXFIFOEmpty(I2C_0_INST))
            ;
        sent += DL_I2C_fillControllerTXFIFO(I2C_0_INST, buf + sent, (uint16_t)(len - sent));
    }
    while (DL_I2C_getControllerStatus(I2C_0_INST) & DL_I2C_CONTROLLER_STATUS_BUSY)
        ;
}

static void oled_write_cmd(uint8_t cmd)
{
    uint8_t buf[2] = {0x00, cmd};//0x00: 后续字节为命令 / control byte: command
    oled_i2c_send(buf, 2);
}

static void oled_write_data(const uint8_t *data, uint8_t len)
{
    uint8_t buf[1 + OLED_LINE_CHARS * 6];
    buf[0] = 0x40;//0x40: 后续字节为显存数据 / control byte: GDDRAM data
    for (uint8_t i = 0; i < len; i++)    buf[1 + i] = data[i];
    oled_i2c_send(buf, (uint16_t)(len + 1));
}

//设置页寻址模式下的光标位置 / set cursor (page addressing mode)
static void oled_set_pos(uint8_t col, uint8_t page)
{
    oled_write_cmd(0xB0 | page);
    oled_write_cmd(0x00 | (col & 0x0F));
    oled_write_cmd(0x10 | (col >> 4));
}

/*
 * 6x8 ASCII点阵(列式, LSB在上), 只收录显示用到的字符, 其余字符显示为空格
 * 6x8 ASCII glyphs (column-major, LSB on top); unlisted chars render as space
 */
static const struct {
    char    ch;
    uint8_t dot[6];
} oled_font[] = {
    {' ', {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}},
    {'.', {0x00, 0x00, 0x00, 0x00, 0x30, 0x30}},
    {':', {0x00, 0x36, 0x36, 0x00, 0x00, 0x00}},
    {'0', {0x00, 0x3E, 0x51, 0x49, 0x45, 0x3E}},
    {'1', {0x00, 0x00, 0x42, 0x7F, 0x40, 0x00}},
    {'2', {0x00, 0x42, 0x61, 0x51, 0x49, 0x46}},
    {'3', {0x00, 0x21, 0x41, 0x45, 0x4B, 0x31}},
    {'4', {0x00, 0x18, 0x14, 0x12, 0x7F, 0x10}},
    {'5', {0x00, 0x27, 0x45, 0x45, 0x45, 0x39}},
    {'6', {0x00, 0x3C, 0x4A, 0x49, 0x49, 0x30}},
    {'7', {0x00, 0x01, 0x71, 0x09, 0x05, 0x03}},
    {'8', {0x00, 0x36, 0x49, 0x49, 0x49, 0x36}},
    {'9', {0x00, 0x06, 0x49, 0x49, 0x29, 0x1E}},
    {'e', {0x00, 0x38, 0x54, 0x54, 0x54, 0x18}},
    {'i', {0x00, 0x00, 0x48, 0x7A, 0x40, 0x00}},
    {'m', {0x00, 0x7C, 0x04, 0x78, 0x04, 0x78}},
    {'s', {0x00, 0x48, 0x54, 0x54, 0x54, 0x24}},
    {'t', {0x00, 0x00, 0x04, 0x3F, 0x44, 0x24}},
};

static const uint8_t *oled_glyph(char ch)
{
    for (uint8_t i = 0; i < sizeof(oled_font) / sizeof(oled_font[0]); i++)
    {
        if (oled_font[i].ch == ch)    return oled_font[i].dot;
    }
    return oled_font[0].dot;//未收录字符按空格显示, 不产生乱码 / unknown chars show as space
}

static void oled_show_string(uint8_t col, uint8_t page, const char *str)
{
    uint8_t data[OLED_LINE_CHARS * 6];
    uint8_t n = 0;

    oled_set_pos(col, page);
    while (*str && n < OLED_LINE_CHARS)
    {
        const uint8_t *g = oled_glyph(*str++);
        for (uint8_t i = 0; i < 6; i++)    data[n * 6 + i] = g[i];
        n++;
    }
    oled_write_data(data, (uint8_t)(n * 6));
}

static void oled_clear(void)
{
    uint8_t blank[8] = {0};
    for (uint8_t page = 0; page < 8; page++)
    {
        oled_set_pos(0, page);
        for (uint8_t i = 0; i < OLED_WIDTH / 8; i++)    oled_write_data(blank, 8);
    }
}

void OLED_Init(void)
{
    static const uint8_t init_cmd[] = {
        0xAE,       //display off
        0xD5, 0x80, //display clock divide
        0xA8, 0x3F, //multiplex ratio 63 (128x64)
        0xD3, 0x00, //display offset 0
        0x40,       //display start line 0
        0x8D, 0x14, //charge pump enable
        0x20, 0x02, //memory mode: page addressing
        0xA1,       //segment remap (column 127 mapped to SEG0)
        0xC8,       //COM scan dec
        0xDA, 0x12, //COM pins config
        0x81, 0xCF, //contrast
        0xD9, 0xF1, //pre-charge period
        0xDB, 0x40, //VCOMH level
        0xA4,       //resume display from RAM
        0xA6,       //normal display (not inverted)
        0xAF,       //display on
    };

    delay_ms(100);//等待OLED上电稳定 / wait for panel power-up
    for (uint8_t i = 0; i < sizeof(init_cmd); i++)    oled_write_cmd(init_cmd[i]);
    oled_clear();
}

//把毫秒格式化为 "time: SS.CCs" 并补足固定宽度(空格), 只含ASCII字符
//format ms as "time: SS.CCs", space padded, ASCII only
static void format_time(uint32_t ms, char *out)
{
    static const char prefix[] = "time: ";
    uint32_t s  = ms / 1000;
    uint32_t cs = (ms % 1000) / 10;//百分之一秒 / centiseconds
    char num[11];
    uint8_t npos = 0, pos = 0;

    if (s > 99999)    s = 99999;//防止超宽, 实际运行远小于此 / clamp, real runs are way shorter

    do {
        num[npos++] = (char)('0' + (s % 10));
        s /= 10;
    } while (s > 0 && npos < sizeof(num));

    for (uint8_t i = 0; i < sizeof(prefix) - 1; i++)    out[pos++] = prefix[i];
    while (npos > 0)    out[pos++] = num[--npos];
    out[pos++] = '.';
    out[pos++] = (char)('0' + (cs / 10));
    out[pos++] = (char)('0' + (cs % 10));
    out[pos++] = 's';
    while (pos < OLED_LINE_CHARS)    out[pos++] = ' ';
    out[pos] = '\0';
}

void OLED_ShowTimeFinal(uint32_t ms)
{
    char str[OLED_LINE_CHARS + 1];
    format_time(ms, str);
    oled_show_string(OLED_TIME_COL, OLED_TIME_PAGE, str);
}

//约100ms刷新一次的秒表显示 / stopwatch refresh throttled to ~100ms
void OLED_ShowTime(uint32_t ms)
{
    static uint32_t last_ms = 0;

    if ((g_run_ms - last_ms) < 100)    return;
    last_ms = g_run_ms;
    OLED_ShowTimeFinal(ms);
}
