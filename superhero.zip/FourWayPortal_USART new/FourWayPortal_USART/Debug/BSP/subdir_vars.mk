################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/Four_linewalking.c \
../BSP/app_motor.c \
../BSP/app_motor_usart.c \
../BSP/bsp_motor_usart.c \
../BSP/delay.c \
../BSP/oled.c \
../BSP/usart.c 

C_DEPS += \
./BSP/Four_linewalking.d \
./BSP/app_motor.d \
./BSP/app_motor_usart.d \
./BSP/bsp_motor_usart.d \
./BSP/delay.d \
./BSP/oled.d \
./BSP/usart.d 

OBJS += \
./BSP/Four_linewalking.o \
./BSP/app_motor.o \
./BSP/app_motor_usart.o \
./BSP/bsp_motor_usart.o \
./BSP/delay.o \
./BSP/oled.o \
./BSP/usart.o 

OBJS__QUOTED += \
"BSP\Four_linewalking.o" \
"BSP\app_motor.o" \
"BSP\app_motor_usart.o" \
"BSP\bsp_motor_usart.o" \
"BSP\delay.o" \
"BSP\oled.o" \
"BSP\usart.o" 

C_DEPS__QUOTED += \
"BSP\Four_linewalking.d" \
"BSP\app_motor.d" \
"BSP\app_motor_usart.d" \
"BSP\bsp_motor_usart.d" \
"BSP\delay.d" \
"BSP\oled.d" \
"BSP\usart.d" 

C_SRCS__QUOTED += \
"../BSP/Four_linewalking.c" \
"../BSP/app_motor.c" \
"../BSP/app_motor_usart.c" \
"../BSP/bsp_motor_usart.c" \
"../BSP/delay.c" \
"../BSP/oled.c" \
"../BSP/usart.c" 


