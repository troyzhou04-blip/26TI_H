################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/TI/ccs/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/BSP" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-405600040: ../empty.syscfg
	@echo 'SysConfig - building file: "$<"'
	"D:/TI/ccs/sysconfig_1.26.2/sysconfig_cli.bat" -s "D:/TI/ccs/mspm0_sdk_2_11_00_07/.metadata/product.json" --script "D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/empty.syscfg" -o "syscfg" --compiler ticlang
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/device_linker.cmd: build-405600040 ../empty.syscfg
syscfg/device.opt: build-405600040
syscfg/device.cmd.genlibs: build-405600040
syscfg/ti_msp_dl_config.c: build-405600040
syscfg/ti_msp_dl_config.h: build-405600040
syscfg/Event.dot: build-405600040
syscfg: build-405600040

syscfg/%.o: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/TI/ccs/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/BSP" -gdwarf-3 -MMD -MP -MF"syscfg/$(basename $(<F)).d_raw" -MT"$(@)" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

startup_mspm0g350x_ticlang.o: D:/TI/ccs/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/TI/ccs/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/BSP" -gdwarf-3 -MMD -MP -MF"$(basename $(<F)).d_raw" -MT"$(@)" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


