################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
BSP/%.o: ../BSP/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/TI/ccs/ti_cgt_arm_llvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"syscfg/device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O2 -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source/third_party/CMSIS/Core/Include" -I"D:/TI/ccs/mspm0_sdk_2_11_00_07/source" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/BSP" -gdwarf-3 -MMD -MP -MF"BSP/$(basename $(<F)).d_raw" -MT"$(@)" -I"D:/TI/FourWayPortal_USART hero/FourWayPortal_USART ultimatev1.1success(1)/FourWayPortal_USART ultimatev1.1success/FourWayPortal_USART new/FourWayPortal_USART/Debug/syscfg"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


